# ChatMesh currently does not require custom ProGuard rules.
