package br.com.chatmesh

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import java.security.PublicKey

class MainActivity : AppCompatActivity() {
    private lateinit var nameInput: EditText
    private lateinit var status: TextView
    private lateinit var log: TextView
    private lateinit var messageInput: EditText
    private lateinit var peersSpinner: Spinner
    private val store by lazy { IdentityStore(this) }
    private val peers = mutableListOf<Pair<String,String>>()
    private lateinit var mesh: MeshNode
    private val REQUEST_BT = 100

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestBluetoothPermissions()
        buildUi()

        mesh = MeshNode(
            this,
            onLog = { runOnUiThread { log.append("\n$it") } },
            onMessage = { from, text ->
                runOnUiThread { log.append("\n📩 [$from] $text") }
            },
            onPeer = { id, name, key ->
                runOnUiThread { addPeer(id, name) }
            }
        )

        nameInput.setText(store.userName())

        findViewById<Button>(R.id.start).setOnClickListener {
            val name = nameInput.text.toString().trim()
            if (name.isEmpty()) {
                nameInput.error = "Digite seu nome"
                return@setOnClickListener
            }
            store.setUserName(name)
            val id = mesh.start(name)
            status.text = "🟢 Mesh ativa • seu ID: $id"
        }

        findViewById<Button>(R.id.scan).setOnClickListener {
            showPairedDevices()
        }

        findViewById<Button>(R.id.send).setOnClickListener {
            val pos = peersSpinner.selectedItemPosition
            if (pos !in peers.indices) {
                Toast.makeText(this, "Conecte primeiro a um amigo.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val msg = messageInput.text.toString().trim()
            if (msg.isEmpty()) return@setOnClickListener
            val ok = mesh.send(peers[pos].first, msg)
            if (ok) {
                log.append("\n➡️ Você: $msg")
                messageInput.text.clear()
            } else {
                Toast.makeText(this, "O destinatário ainda não está conectado.", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun addPeer(id: String, name: String) {
        if (peers.none { it.first == id }) {
            peers.add(id to name)
            peersSpinner.adapter = ArrayAdapter(
                this,
                android.R.layout.simple_spinner_dropdown_item,
                peers.map { "${it.second} • ${it.first}" }
            )
        }
    }

    private fun showPairedDevices() {
        val adapter = BluetoothAdapter.getDefaultAdapter() ?: return
        if (!adapter.isEnabled) {
            status.text = "Ative o Bluetooth."
            return
        }
        val bonded = runCatching { adapter.bondedDevices }.getOrNull().orEmpty()
        if (bonded.isEmpty()) {
            status.text = "Nenhum aparelho pareado. Pareie os celulares nas configurações do Android."
            return
        }
        bonded.forEach { device ->
            runCatching { mesh.connect(device) }
        }
        status.text = "🔎 Conectando aos aparelhos pareados..."
    }

    private fun requestBluetoothPermissions() {
        if (android.os.Build.VERSION.SDK_INT >= 31) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(
                    Manifest.permission.BLUETOOTH_SCAN,
                    Manifest.permission.BLUETOOTH_CONNECT,
                    Manifest.permission.BLUETOOTH_ADVERTISE
                ),
                REQUEST_BT
            )
        }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 32, 32, 32)
        }
        root.addView(TextView(this).apply {
            text = "Chat Mesh"
            textSize = 28f
        })

        nameInput = EditText(this).apply {
            hint = "Seu nome"
            singleLine = true
        }
        root.addView(nameInput)

        root.addView(Button(this).apply {
            id = R.id.start
            text = "Ativar minha rede mesh"
        })
        root.addView(Button(this).apply {
            id = R.id.scan
            text = "Conectar aparelhos pareados"
        })

        status = TextView(this).apply {
            text = "🔴 Mesh desativada"
            textSize = 16f
        }
        root.addView(status)

        peersSpinner = Spinner(this)
        root.addView(peersSpinner)

        messageInput = EditText(this).apply { hint = "Mensagem" }
        root.addView(messageInput)

        root.addView(Button(this).apply {
            id = R.id.send
            text = "Enviar mensagem"
        })

        log = TextView(this).apply {
            text = "Eventos:"
            textSize = 14f
        }
        root.addView(log)

        setContentView(root)
    }
}
