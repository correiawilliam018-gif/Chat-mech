package br.com.chatmesh

import android.bluetooth.*
import android.content.Context
import kotlinx.coroutines.*
import java.nio.charset.StandardCharsets
import java.security.PublicKey
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

class MeshNode(
    private val context: Context,
    private val onLog: (String) -> Unit,
    private val onMessage: (String, String) -> Unit,
    private val onPeer: (String, String, PublicKey) -> Unit
) {
    companion object {
        val SERVICE_UUID: UUID =
            UUID.fromString("7f5e2a90-9f2b-4a8c-8f16-7d0d1e6d4b21")
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val seen = ConcurrentHashMap.newKeySet<String>()
    private val peers = ConcurrentHashMap<String, BluetoothSocket>()
    private val peerKeys = ConcurrentHashMap<String, PublicKey>()
    private val peerNames = ConcurrentHashMap<String, String>()
    private var identity: Crypto.Identity? = null
    private var localId = ""
    private var userName = ""
    private var server: BluetoothServerSocket? = null
    @Volatile private var running = false

    fun start(name: String): String {
        if (running) return localId
        userName = name
        identity = IdentityStore(context).getOrCreate()
        localId = Crypto.idFromPublicKey(identity!!.publicKey)
        running = true
        startServer()
        onLog("🟢 Nó ativo: $localId")
        return localId
    }

    private fun startServer() {
        val adapter = BluetoothAdapter.getDefaultAdapter()
        scope.launch {
            runCatching {
                server = adapter.listenUsingRfcommWithServiceRecord("Chat Mesh", SERVICE_UUID)
                while (running) {
                    val socket = server?.accept() ?: break
                    registerPeer(socket)
                }
            }.onFailure { onLog("Servidor Bluetooth: ${it.message}") }
        }
    }

    fun stop() {
        running = false
        runCatching { server?.close() }
        peers.values.forEach { runCatching { it.close() } }
        peers.clear()
        peerKeys.clear()
        peerNames.clear()
    }

    fun connect(device: BluetoothDevice) {
        scope.launch {
            runCatching {
                val socket = device.createRfcommSocketToServiceRecord(SERVICE_UUID)
                socket.connect()
                registerPeer(socket)
            }.onFailure {
                onLog("Falha ao conectar ${device.name ?: device.address}: ${it.message}")
            }
        }
    }

    private fun registerPeer(socket: BluetoothSocket) {
        val device = socket.remoteDevice
        onLog("🔗 Conectado: ${device.name ?: device.address}")
        val me = identity ?: return
        socket.outputStream.write(
            ("H1|$localId|${Crypto.publicKeyB64(me.publicKey)}|$userName\n")
                .toByteArray(StandardCharsets.UTF_8)
        )
        socket.outputStream.flush()
        scope.launch { readLoop(socket) }
    }

    private suspend fun readLoop(socket: BluetoothSocket) {
        val reader = socket.inputStream.bufferedReader(StandardCharsets.UTF_8)
        while (running) {
            val line = reader.readLine() ?: break
            if (line.startsWith("H1|")) {
                val p = line.split("|", limit = 4)
                if (p.size == 4) {
                    val id = p[1]
                    val key = runCatching { Crypto.publicKeyFromB64(p[2]) }.getOrNull()
                    if (key != null) {
                        peers[id] = socket
                        peerKeys[id] = key
                        peerNames[id] = p[3]
                        onPeer(id, p[3], key)
                        onLog("👤 Vizinho: ${p[3]} [$id]")
                    }
                }
                continue
            }

            val packet = MeshPacket.decode(line) ?: continue
            if (!seen.add(packet.id)) continue
            if (packet.ttl <= 0) continue

            if (packet.destination == localId) {
                val senderKey = runCatching {
                    Crypto.publicKeyFromB64(packet.sourcePublicKey)
                }.getOrNull() ?: continue
                val me = identity ?: continue
                val contextKey = "${packet.source}->${packet.destination}"
                val text = runCatching {
                    Crypto.decrypt(me.privateKey, senderKey, contextKey, packet.ciphertext)
                }.getOrNull()

                if (text != null) {
                    onMessage(packet.source, text)
                } else {
                    onLog("⚠️ Pacote rejeitado: falha de autenticação.")
                }
            } else {
                forward(packet, socket)
            }
        }
    }

    private fun forward(packet: MeshPacket, incoming: BluetoothSocket) {
        if (packet.ttl <= 1) return
        val next = packet.copy(ttl = packet.ttl - 1).encode() + "\n"
        peers.values
            .filter { it !== incoming }
            .forEach { socket ->
                scope.launch {
                    runCatching {
                        socket.outputStream.write(next.toByteArray(StandardCharsets.UTF_8))
                        socket.outputStream.flush()
                    }
                }
            }
    }

    fun send(destination: String, plain: String): Boolean {
        val me = identity ?: return false
        val destinationKey = peerKeys[destination] ?: return false
        val contextKey = "${localId}->${destination}"
        val encrypted = Crypto.encrypt(me.privateKey, destinationKey, contextKey, plain)
        val packet = MeshPacket(
            MeshPacket.newId(),
            localId,
            destination,
            8,
            Crypto.publicKeyB64(me.publicKey),
            encrypted
        )
        seen.add(packet.id)
        val line = packet.encode() + "\n"

        peers.values.forEach { socket ->
            scope.launch {
                runCatching {
                    socket.outputStream.write(line.toByteArray(StandardCharsets.UTF_8))
                    socket.outputStream.flush()
                }
            }
        }
        return peers.isNotEmpty()
    }

    fun peerList(): List<Pair<String,String>> =
        peerNames.entries.sortedBy { it.value }.map { it.key to it.value }
}
