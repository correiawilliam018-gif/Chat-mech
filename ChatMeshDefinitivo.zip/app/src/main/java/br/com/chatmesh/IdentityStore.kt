package br.com.chatmesh

import android.content.Context
import android.util.Base64
import java.security.KeyPair
import java.security.KeyPairGenerator
import java.security.KeyStore
import java.security.PrivateKey
import java.security.PublicKey

class IdentityStore(private val context: Context) {
    private val alias = "chatmesh_identity_v1"
    private val prefs = context.getSharedPreferences("identity", Context.MODE_PRIVATE)

    fun getOrCreate(): Crypto.Identity {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        if (!ks.containsAlias(alias)) {
            val gen = KeyPairGenerator.getInstance("EC", "AndroidKeyStore")
            gen.initialize(android.security.keystore.KeyGenParameterSpec.Builder(
                alias,
                android.security.keystore.KeyProperties.PURPOSE_AGREE_KEY
            ).setAlgorithmParameterSpec(java.security.spec.ECGenParameterSpec("secp256r1"))
             .setDigests(android.security.keystore.KeyProperties.DIGEST_SHA256)
             .build())
            gen.generateKeyPair()
        }
        val entry = ks.getEntry(alias, null) as KeyStore.PrivateKeyEntry
        return Crypto.Identity(entry.privateKey, entry.certificate.publicKey)
    }

    fun userName(): String = prefs.getString("name", "") ?: ""
    fun setUserName(name: String) { prefs.edit().putString("name", name).apply() }
}
