package br.com.chatmesh

import android.util.Base64
import java.nio.charset.StandardCharsets
import java.security.KeyFactory
import java.security.KeyPairGenerator
import java.security.MessageDigest
import java.security.PrivateKey
import java.security.PublicKey
import java.security.spec.X509EncodedKeySpec
import javax.crypto.Cipher
import javax.crypto.KeyAgreement
import javax.crypto.Mac
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

object Crypto {
    data class Identity(val privateKey: PrivateKey, val publicKey: PublicKey)

    fun createIdentity(): Identity {
        val gen = KeyPairGenerator.getInstance("EC")
        gen.initialize(256)
        val pair = gen.generateKeyPair()
        return Identity(pair.private, pair.public)
    }

    fun publicKeyB64(key: PublicKey): String =
        Base64.encodeToString(key.encoded, Base64.NO_WRAP)

    fun publicKeyFromB64(value: String): PublicKey =
        KeyFactory.getInstance("EC")
            .generatePublic(X509EncodedKeySpec(Base64.decode(value, Base64.NO_WRAP)))

    private fun sharedKey(privateKey: PrivateKey, peer: PublicKey, context: String): ByteArray {
        val ka = KeyAgreement.getInstance("ECDH")
        ka.init(privateKey)
        ka.doPhase(peer, true)
        val secret = ka.generateSecret()
        val digest = MessageDigest.getInstance("SHA-256")
        return digest.digest(("ChatMesh-v1|" + context).toByteArray(StandardCharsets.UTF_8) + secret)
    }

    fun encrypt(privateKey: PrivateKey, peer: PublicKey, context: String, plain: String): String {
        val key = SecretKeySpec(sharedKey(privateKey, peer, context), "AES")
        val iv = ByteArray(12).also { java.security.SecureRandom().nextBytes(it) }
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key, GCMParameterSpec(128, iv))
        val out = cipher.doFinal(plain.toByteArray(StandardCharsets.UTF_8))
        return Base64.encodeToString(iv + out, Base64.NO_WRAP)
    }

    fun decrypt(privateKey: PrivateKey, peer: PublicKey, context: String, packed: String): String {
        val raw = Base64.decode(packed, Base64.NO_WRAP)
        require(raw.size > 12) { "Pacote criptografado inválido" }
        val iv = raw.copyOfRange(0, 12)
        val body = raw.copyOfRange(12, raw.size)
        val key = SecretKeySpec(sharedKey(privateKey, peer, context), "AES")
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(128, iv))
        return String(cipher.doFinal(body), StandardCharsets.UTF_8)
    }

    fun idFromPublicKey(publicKey: PublicKey): String {
        val hash = MessageDigest.getInstance("SHA-256").digest(publicKey.encoded)
        return hash.take(8).joinToString("") { "%02x".format(it) }
    }
}
