package br.com.chatmesh

import java.util.UUID

data class MeshPacket(
    val id: String,
    val source: String,
    val destination: String,
    val ttl: Int,
    val sourcePublicKey: String,
    val ciphertext: String
) {
    fun encode(): String = listOf(
        "M1", id, source, destination, ttl.toString(), sourcePublicKey, ciphertext
    ).joinToString("|")

    companion object {
        fun decode(line: String): MeshPacket? {
            val p = line.split("|", limit = 7)
            if (p.size != 7 || p[0] != "M1") return null
            return runCatching {
                MeshPacket(p[1], p[2], p[3], p[4].toInt(), p[5], p[6])
            }.getOrNull()
        }

        fun newId(): String = UUID.randomUUID().toString()
    }
}
