# Chat Mesh — versão 1.0

Projeto Android para comunicação local sem internet, com arquitetura de rede mesh.

## O que esta versão muda

- Identidade persistente protegida pelo Android Keystore.
- Identificador do nó derivado da chave pública.
- Mensagens com ID único e TTL para evitar loops.
- Encaminhamento sem duplicar o cabeçalho do pacote.
- Destino explícito: `source -> destination`.
- Criptografia ponta a ponta entre remetente e destinatário com ECDH P-256 + AES-GCM.
- Nós intermediários só encaminham o pacote cifrado.
- Sem servidor de internet para o transporte Bluetooth.
- Workflow GitHub Actions para gerar o APK na nuvem.

## Importante

Esta é uma base funcional/educacional e NÃO deve ser considerada um mensageiro de segurança crítica. A camada de descoberta, roteamento, ACK/retransmissão, fragmentação BLE e UX de seleção de destinatários ainda precisa ser endurecida para uma publicação real.

Também não existe "Bluetooth ilimitado": a distância depende dos aparelhos, obstáculos e da quantidade/posição dos nós. Satélite exige hardware/serviço compatível; o aplicativo não cria uma conexão via satélite grátis.

## Como gerar o APK pelo celular

1. Crie uma conta no GitHub pelo navegador.
2. Crie um repositório novo, por exemplo `chat-mesh`.
3. Envie todos os arquivos deste projeto para o repositório.
4. Abra a aba **Actions**.
5. Execute **Build APK**.
6. Quando terminar, abra a execução e baixe o artefato **ChatMesh-debug**.
7. Extraia o ZIP e instale `app-debug.apk`.
8. Se o Android bloquear, permita "instalar apps desconhecidos" para o navegador/gerenciador de arquivos usado.

## Teste mesh

Use pelo menos 3 celulares:
A — B — C.

O objetivo é A enviar para C passando por B. Todos precisam estar próximos o suficiente para seus respectivos enlaces Bluetooth.

## Status desta versão

Esta entrega já inclui servidor RFCOMM, conexão entre aparelhos pareados, handshake de identidade, encaminhamento multi-hop, TTL, deduplicação e criptografia ponta a ponta. Ainda é uma versão de testes: antes de publicar na Play Store, faça testes em vários modelos de Android e uma auditoria de segurança.

## Próximas melhorias para publicação

- BLE GATT em vez de depender de RFCOMM.
- descoberta automática de vizinhos.
- tabela de rotas e descoberta de rota.
- ACK, retry e store-and-forward.
- fragmentação/reassemblagem.
- confirmação de identidade por QR/código.
- tela de contatos/nós e envio real para um destinatário.
- serviço foreground/background para manter a rede ativa dentro das limitações do Android.
- testes automatizados e auditoria de segurança.
